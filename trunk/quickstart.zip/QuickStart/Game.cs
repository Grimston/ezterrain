using System;
using System.Drawing;

using OpenTK;
using OpenTK.Graphics;
using OpenTK.Audio;
using OpenTK.Math;
using OpenTK.Input;
using OpenTK.Platform;
using System.Drawing.Imaging;

namespace StarterKit
{
	class Game : GameWindow
	{
		// Creates a new TextPrinter to draw text on the screen.
		TextPrinter printer = new TextPrinter(TextQuality.Medium);
		Font sans_serif = new Font(FontFamily.GenericSansSerif, 18.0f);
		int vertexBuffer, indexBuffer;
		Vector3 viewer;
		const int SideCount = 257;

		Program program;
		DateTime start;

		/// <summary>Creates a 800x600 window with the specified title.</summary>
		public Game()
			: base(800, 600, GraphicsMode.Default, "OpenTK Quick Start Sample")
		{
			VSync = VSyncMode.Off;
			start = DateTime.MinValue;
			viewer = new Vector3(0, 0, 1500);
		}

		/// <summary>Load resources here.</summary>
		/// <param name="e">Not used.</param>
		public override void OnLoad(EventArgs e)
		{
			GL.ClearColor(System.Drawing.Color.SteelBlue);
			GL.Enable(EnableCap.DepthTest);
		}

		/// <summary>
		/// Called when your window is resized. Set your viewport here. It is also
		/// a good place to set up your projection matrix (which probably changes
		/// along when the aspect ratio of your window).
		/// </summary>
		/// <param name="e">Contains information on the new Width and Size of the GameWindow.</param>
		protected override void OnResize(ResizeEventArgs e)
		{
			GL.Viewport(0, 0, Width, Height);
			GL.MatrixMode(MatrixMode.Projection);
			GL.LoadIdentity();
			Glu.Perspective(45.0, Width / (double)Height, 1.0, 6400.0);
		}

		/// <summary>
		/// Called when it is time to setup the next frame. Add you game logic here.
		/// </summary>
		/// <param name="e">Contains timing information for framerate independent logic.</param>
		public override void OnUpdateFrame(UpdateFrameEventArgs e)
		{
			if (Keyboard[Key.Escape])
				Exit();
			else if (Keyboard[Key.Up])
			{
				viewer += 10 * Vector3.UnitY;
			}
			else if (Keyboard[Key.Down])
			{
				viewer -= 10 * Vector3.UnitY;
			}
			else if (Keyboard[Key.Right])
			{
				viewer += 10 * Vector3.UnitX;
			}
			else if (Keyboard[Key.Left])
			{
				viewer -= 10 * Vector3.UnitX;
			}
			else if (Keyboard[Key.W])
			{
				viewer -= 10 * Vector3.UnitZ;
			}
			else if (Keyboard[Key.S])
			{
				viewer += 10 * Vector3.UnitZ;
			}
		}

		Mesh mesh;

		/// <summary>
		/// Called when it is time to render the next frame. Add your rendering code here.
		/// </summary>
		/// <param name="e">Contains timing information.</param>
		public override void OnRenderFrame(RenderFrameEventArgs e)
		{
			BeginFrame();

			CheckProgram();

			UseProgram();

			UpdateTimeUniform();
			UpdateUniforms();

			if (mesh == null)
			{
				mesh = InitMesh();
			}

			if (textureHandle == 0)
			{
				LoadTexture("noise.bmp");
			}

			BindBuffers(mesh);

			DrawBuffers(mesh);

			RenderFPS(e.Time);

			SwapBuffers();
		}

		private void UpdateUniforms()
		{
			int location = GL.GetUniformLocation(program.Handle, "noise");
			GL.Uniform1(location, 0);

			location = GL.GetUniformLocation(program.Handle, "maxVertex");
			GL.Uniform1(location, (float)SideCount);
		}

		public override void OnUnload(EventArgs e)
		{
			program.Dispose();
			base.OnUnload(e);
		}

		private void UpdateTimeUniform()
		{
			if (start == DateTime.MinValue)
			{
				start = DateTime.Now;
			}

			int location = GL.GetUniformLocation(program.Handle, "time");
			GL.Uniform1(location, (float)(DateTime.Now - start).TotalSeconds);
		}

		private void DrawBuffers(Mesh mesh)
		{
			GL.EnableClientState(EnableCap.VertexArray);

			GL.BindBuffer(BufferTarget.ArrayBuffer, vertexBuffer);

			SetColorUniform(0);
			GL.VertexPointer(Vertex.NumCoords, VertexPointerType.Float, 0, 0);
			GL.DrawElements(BeginMode.Triangles, mesh.Indices.Length, DrawElementsType.UnsignedInt, IntPtr.Zero);

			SetColorUniform(1);
			GL.Scale(new Vector3(-1, 1, 1));
			GL.VertexPointer(Vertex.NumCoords, VertexPointerType.Float, 0, 0);
			GL.DrawElements(BeginMode.Triangles, mesh.Indices.Length, DrawElementsType.UnsignedInt, IntPtr.Zero);

			GL.DisableClientState(EnableCap.VertexArray);

			GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
			GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
		}

		private void SetColorUniform(int value)
		{
			int location = GL.GetUniformLocation(program.Handle, "color");
			GL.Uniform1(location, value);
		}

		private void BindBuffers(Mesh mesh)
		{
			GL.BindBuffer(BufferTarget.ArrayBuffer, vertexBuffer);
			GL.BufferData(BufferTarget.ArrayBuffer,
						  new IntPtr(mesh.Vertices.Length * Vertex.Size),
						  mesh.Vertices,
						  BufferUsageHint.StreamDraw);

			GL.BindBuffer(BufferTarget.ElementArrayBuffer, indexBuffer);
			GL.BufferData(BufferTarget.ElementArrayBuffer,
						  new IntPtr(mesh.Indices.Length * 4),
						  mesh.Indices,
						  BufferUsageHint.StreamDraw);

			//GL.BindBuffer(BufferTarget.ArrayBuffer, transformBuffer);
			//GL.BufferData(BufferTarget.ArrayBuffer,
			//              new IntPtr(mesh.Vertices.Length * Vertex.Size),
			//              IntPtr.Zero, 
			//              BufferUsageHint.StaticDraw);
			//GL.TransformFeedbackVaryings(program.Handle, 1, "gl_Position", TransformFeedbackMode.SeparateAttribs);
		}

		private void CheckProgram()
		{
			if (program == null)
			{
				Shader vertexShader = Shader.FromFile(ShaderType.VertexShader, "program.vert");
				Shader fragmentShader = Shader.FromFile(ShaderType.FragmentShader, "program.frag");

				program = new Program();
				program.Initialize(vertexShader, fragmentShader);
			}
		}

		private void UseProgram()
		{
			GL.UseProgram(program.Handle);
		}

		private Mesh InitMesh()
		{
			Tile tile = new Tile(SideCount);

			return tile.Mesh;

			//return new Mesh(new Vertex[3]{new Vertex(-1.0f, -1.0f, 4.0f),
			//                              new Vertex(1.0f, -1.0f, 4.0f),
			//                              new Vertex(0.0f, 1.0f, 4.0f)},
			//                new uint[3] { 0, 1, 2 });
		}

		private void RenderFPS(double time)
		{
			GL.UseProgram(0);
			GL.Disable(EnableCap.Texture2D);

			printer.Begin();

			printer.Print(((int)(1 / time)).ToString("F0"), sans_serif, Color.SpringGreen);

			printer.End();
		}

		private void BeginFrame()
		{
			GL.Clear(ClearBufferMask.ColorBufferBit |
							  ClearBufferMask.DepthBufferBit);

			GL.MatrixMode(MatrixMode.Modelview);
			GL.LoadIdentity();
			Glu.LookAt(viewer, viewer - Vector3.UnitZ, Vector3.UnitY);

			//GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Line);
			GL.Enable(EnableCap.Texture2D);

			if (indexBuffer == 0 || vertexBuffer == 0 /*|| transformBuffer == 0*/)
			{
				GL.GenBuffers(1, out vertexBuffer);
				GL.GenBuffers(1, out indexBuffer);
				//GL.GenBuffers(1, out transformBuffer);
			}
		}

		int textureHandle;

		private void LoadTexture(string fileName)
		{
			if (System.IO.File.Exists(fileName))
			{
				//make a bitmap out of the file on the disk
				Bitmap textureBitmap = new Bitmap(fileName);
				//get the data out of the bitmap
				BitmapData textureData = textureBitmap.LockBits(
						new Rectangle(0, 0, textureBitmap.Width, textureBitmap.Height),
									  ImageLockMode.ReadOnly,
									  System.Drawing.Imaging.PixelFormat.Format24bppRgb
					);
				//Code to get the data to the OpenGL Driver
				//generate one texture and put its ID number into the "Texture" variable
				GL.GenTextures(1, out textureHandle);
				//tell OpenGL that this is a 2D texture
				GL.BindTexture(TextureTarget.Texture2D, textureHandle);
				//the following code sets certian parameters for the texture
				GL.TexEnv(TextureEnvTarget.TextureEnv,
					TextureEnvParameter.TextureEnvMode,
					(float)TextureEnvMode.Modulate);
				GL.TexParameter(TextureTarget.Texture2D,
					TextureParameterName.TextureMinFilter,
					(float)TextureMinFilter.LinearMipmapLinear);
				GL.TexParameter(TextureTarget.Texture2D,
					TextureParameterName.TextureMagFilter,
					(float)TextureMagFilter.Linear);
				//load the data by telling OpenGL to build mipmaps out of the bitmap data
				Glu.Build2DMipmap(TextureTarget.Texture2D,
								  (int)PixelInternalFormat.Three,
								  textureBitmap.Width, textureBitmap.Height,
								  OpenTK.Graphics.PixelFormat.Bgr, PixelType.UnsignedByte,
								  textureData.Scan0);

				//free the bitmap data (we dont need it anymore because it has been passed to the OpenGL driver
				textureBitmap.UnlockBits(textureData);
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			// The 'using' idiom guarantees proper resource cleanup.
			// We request 30 UpdateFrame events per second, and unlimited
			// RenderFrame events (as fast as the computer can handle).
			using (Game game = new Game())
			{
				game.Run(30.0, 0.0);
			}
		}
	}
}