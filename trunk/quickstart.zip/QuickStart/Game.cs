using System;
using System.Drawing;

using OpenTK;
using OpenTK.Graphics;
using OpenTK.Audio;
using OpenTK.Math;
using OpenTK.Input;
using OpenTK.Platform;

namespace StarterKit
{
	class Game : GameWindow
	{
		// Creates a new TextPrinter to draw text on the screen.
		TextPrinter printer = new TextPrinter(TextQuality.Medium);
		Font sans_serif = new Font(FontFamily.GenericSansSerif, 18.0f);
		int vertexBuffer, indexBuffer;

		Program program;
		DateTime start;

		/// <summary>Creates a 800x600 window with the specified title.</summary>
		public Game()
			: base(800, 600, GraphicsMode.Default, "OpenTK Quick Start Sample")
		{
			VSync = VSyncMode.On;
			start = DateTime.MinValue;
		}

		/// <summary>Load resources here.</summary>
		/// <param name="e">Not used.</param>
		public override void OnLoad(EventArgs e)
		{
			GL.ClearColor(System.Drawing.Color.SteelBlue);
			GL.Enable(EnableCap.DepthTest);
		}

		/// <summary>
		/// Called when your window is resized. Set your viewport here. It is also
		/// a good place to set up your projection matrix (which probably changes
		/// along when the aspect ratio of your window).
		/// </summary>
		/// <param name="e">Contains information on the new Width and Size of the GameWindow.</param>
		protected override void OnResize(ResizeEventArgs e)
		{
			GL.Viewport(0, 0, Width, Height);
			GL.MatrixMode(MatrixMode.Projection);
			GL.LoadIdentity();
			Glu.Perspective(45.0, Width / (double)Height, 1.0, 64.0);
		}

		/// <summary>
		/// Called when it is time to setup the next frame. Add you game logic here.
		/// </summary>
		/// <param name="e">Contains timing information for framerate independent logic.</param>
		public override void OnUpdateFrame(UpdateFrameEventArgs e)
		{
			if (Keyboard[Key.Escape])
				Exit();
		}

		/// <summary>
		/// Called when it is time to render the next frame. Add your rendering code here.
		/// </summary>
		/// <param name="e">Contains timing information.</param>
		public override void OnRenderFrame(RenderFrameEventArgs e)
		{
			BeginFrame();

			CheckProgram();

			UseProgram();

			UpdateTimeUniform();

			Mesh mesh = InitMesh();

			BindBuffers(mesh);

			DrawBuffers(mesh);

			RenderFPS(e.Time);

			SwapBuffers();
		}

		public override void OnUnload(EventArgs e)
		{
			program.Dispose();
			base.OnUnload(e);
		}

		private void UpdateTimeUniform()
		{
			if (start == DateTime.MinValue)
			{
				start = DateTime.Now;
			}

			int location = GL.GetUniformLocation(program.Handle, "time");
			GL.Uniform1(location, (float)(DateTime.Now - start).TotalSeconds);
		}

		private void DrawBuffers(Mesh mesh)
		{
			GL.EnableClientState(EnableCap.VertexArray);

			GL.VertexPointer(Vertex.NumCoords, VertexPointerType.Float, 0, 0);
			GL.DrawElements(BeginMode.Triangles, mesh.Indices.Length, DrawElementsType.UnsignedInt, IntPtr.Zero);

			GL.DisableClientState(EnableCap.VertexArray);

			GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
			GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
		}

		private void BindBuffers(Mesh mesh)
		{
			GL.BindBuffer(BufferTarget.ArrayBuffer, vertexBuffer);
			GL.BufferData(BufferTarget.ArrayBuffer,
						  new IntPtr(mesh.Vertices.Length * Vertex.Size),
						  mesh.Vertices,
						  BufferUsageHint.StreamDraw);

			GL.BindBuffer(BufferTarget.ElementArrayBuffer, indexBuffer);
			GL.BufferData(BufferTarget.ElementArrayBuffer,
						  new IntPtr(mesh.Indices.Length * 4),
						  mesh.Indices,
						  BufferUsageHint.StreamDraw);
		}

		private void CheckProgram()
		{
			if (program == null)
			{
				Shader vertexShader = Shader.FromFile(ShaderType.VertexShader, "program.vert");
				Shader fragmentShader = Shader.FromFile(ShaderType.FragmentShader, "program.frag");

				program = new Program();
				program.Initialize(vertexShader, fragmentShader);
			}
		}

		private void UseProgram()
		{
			GL.UseProgram(program.Handle);
		}

		private Mesh InitMesh()
		{
			return new Mesh(new Vertex[3]{new Vertex(-1.0f, -1.0f, 4.0f),
										  new Vertex(1.0f, -1.0f, 4.0f),
										  new Vertex(0.0f, 1.0f, 4.0f)},
							new uint[3] { 0, 1, 2 });
		}

		private void RenderFPS(double time)
		{
			GL.UseProgram(0);

			printer.Begin();

			printer.Print(((int)(1 / time)).ToString("F0"), sans_serif, Color.SpringGreen);

			printer.End();
		}

		private void BeginFrame()
		{
			GL.Clear(ClearBufferMask.ColorBufferBit |
							  ClearBufferMask.DepthBufferBit);

			GL.MatrixMode(MatrixMode.Modelview);
			GL.LoadIdentity();
			Glu.LookAt(Vector3.Zero, Vector3.UnitZ, Vector3.UnitY);

			if (indexBuffer == 0 || vertexBuffer == 0)
			{
				GL.GenBuffers(1, out vertexBuffer);
				GL.GenBuffers(1, out indexBuffer);
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			// The 'using' idiom guarantees proper resource cleanup.
			// We request 30 UpdateFrame events per second, and unlimited
			// RenderFrame events (as fast as the computer can handle).
			using (Game game = new Game())
			{
				game.Run(30.0, 0.0);
			}
		}
	}
}