﻿using System;
using OpenTK.Math;

namespace StarterKit
{
	class Mesh
	{
		public Mesh(Vertex[] vertices, uint[] indices)
		{
			this.vertices = vertices;
			this.indices = indices;
		}

		public Mesh(uint vertexCount, uint indexCount)
		{
			vertices = new Vertex[vertexCount];
			indices = new uint[indexCount];
		}
		

		Vertex[] vertices;
		public Vertex[] Vertices
		{
			get { return vertices; }
		}

		uint[] indices;
		public uint[] Indices
		{
			get { return indices; }
		}

	}
}
