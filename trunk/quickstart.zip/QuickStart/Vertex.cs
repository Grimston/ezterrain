﻿using System;
using OpenTK.Math;
using System.Runtime.InteropServices;

namespace StarterKit
{
	[Serializable]
	struct Vertex
	{
		public Vertex(float x, float y, float z)
		{
			this.Position = new Vector3(x, y, z);
		}

		public Vertex(Vector3 position)
		{
			this.Position = position;
		}

		public Vector3 Position;

		public const int Size = 12;
		public const int NumCoords = 3;
	}
}
