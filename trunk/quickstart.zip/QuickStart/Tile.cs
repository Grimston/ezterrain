﻿using System;
using System.Text;
using System.Collections.Generic;

namespace StarterKit
{
    class Tile
    {
        public Tile(uint sideSount)
        {
            this.SideCount = sideSount;

            InitializeMesh();
        }

        private void InitializeMesh()
        {
            Vertex[] vertices = InitializeVertices();

            List<uint> indices = new List<uint>();

            for (uint i = 0; i < SideCount - 1; i++)
            {
                for (uint j = 0; j < SideCount - 1; j++)
                {
                    indices.Add(i * SideCount + j);
                    indices.Add(i * SideCount + j + 1);
                    indices.Add((i + 1) * SideCount + j);

                    indices.Add(i * SideCount + j + 1);
                    indices.Add((i + 1) * SideCount + j + 1);
                    indices.Add((i + 1) * SideCount + j);
                }
            }

            this.Mesh = new Mesh(vertices, indices.ToArray());
        }

        private Vertex[] InitializeVertices()
        {
            Vertex[] vertices = new Vertex[TotalCount];

            for (int i = 0, k = 0; i < SideCount; i++)
            {
                for (int j = 0; j < SideCount; j++)
                {
                    vertices[k++] = new Vertex(i, j, -4);
                }
            }
            return vertices;
        }

        public uint SideCount { get; private set; }

        public uint TotalCount
        {
            get { return SideCount * SideCount; }
        }

        public Mesh Mesh { get; private set; }
    }
}
